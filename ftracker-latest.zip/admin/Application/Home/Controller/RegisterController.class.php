<?php 

  namespace Home\Controller;
use Think\Controller;
class RegisterController extends Controller {
        function _empty(){
        	echo "非法操作";
        }
        public function test(){
            echo json_encode(array(1,2,3));
        }
        public function register(){
        $Usertest=D('usertest');

     	 if(IS_POST){
     	 	$data=I("post.");
     	 	$username=$data['username'];
     	 	// if($username==""){
     	 	//    $this->error('用户名不能为空',U('register'),3);	
     	 	// }

     	 	// if($data['password']!==$data['password2']){
        //       $this->error('两次密码不正确',U('register'),3);
     	 	// }
        
     	 	//判断用户账号是否已注册
     	 	 $res=$Usertest->where("username='$username'")->select();
             if($res!=false){
             	$this->error('用户名已存在',U('register'),3);
             }

             $data['password']=md5($data['password']);
             
             $user=$Usertest->add($data);
             if($user){
             	$this->success('注册成功',U('login'),3);

             }else{
             	$this->error('注册失败',U('register'),3);
             }
           	
          
     	  }else{
     	          $this->display(); 
     	  }
       }

    public function login(){
        $Usertest=D('usertest');
        if(IS_POST){
            I('post.');

            $code=I('post.VerificationCode');
            $username=I('post.username');
            $password=MD5(I('post.password'));
            $vry=new \Think\Verify();
            if(!$vry->check($code)){
                $this->error('验证码错误',U('login'),2);
            }
            $res=$Usertest->where(array('username'=>$username,'password'=>$password))->find();
            if($res){
                session('id',$res['id']);
                session('username',$res['username']);
                $this->success('登陆成功',U('Userindex/userindex'));

            }else{
                $this->error('登陆失败',U('login'),3);
            }


        }else{
            $this->display();
        }
    }


     function logina($articleid){
        $Usertest=D('usertest');
        if(IS_POST){
            I('post.');

            $code=I('post.VerificationCode');
            $username=I('post.username');
            $password=MD5(I('post.password'));
            $vry=new \Think\Verify();
            if(!$vry->check($code)){
                $this->error('验证码错误',U('login'),2);
            }
            $res=$Usertest->where(array('username'=>$username,'password'=>$password))->find();
            if($res){
                session('id',$res['id']);
                session('username',$res['username']);
                $this->success('登陆成功',U("Home/Index/content/id/$articleid"));

            }else{
                $this->error('登陆失败',U('login'),3);
            }


        }else{
            $this->display('login');
        }
    }

    public function forgetpwd(){
      $this->display();
     }

    public function doforgetpwd(){  
        $username = I('post.username');
        $row = D('usertest')->where(array('username'=>$username))->find();
        
        if(!$row['username']){
            echo "<script>alert('该邮箱尚未注册');history.go(-1);</script>";
            return;
        }
            $to=$row['username'];
            $title="验证码:";
            $content= rand(100,999);//生成验证码
            
            session('forget_pwd', $content);//保存验证码
             session('id',$row['id']);
            session('username',$row['username']);

            $flag=$this->sendMail($to,$title,$content);//发送验证码           
            if($flag){
            //            echo "<script>alert('密码已通过邮件发送');</script>";
             //            header('Location:'.U('Register/comfirm'));
                 $this->success('密码已通过邮件发送',U('Register/comfirm'),2);
            }else{
                echo "<script>alert('服务器正忙，请稍后再试');</script>";
            }    
    }
    public function comfirm(){
      if(IS_POST){
        if(I('post.forgetpwd') == session('forget_pwd')){
           $this->success('验证成功',U('Userindex/userindex'),2);
        } else {
           session(null);
           $this->error('验证码错误',U('Register/forgetpwd'),2);
        }
      } else {
        $this->display();
      }
     
    }
    //这个sendmail是内部的函数，供给doforgetpwd来使用的。
    function sendMail($to,$title,$content){
        require_once("class.phpmailer.php");
        require_once("class.smtp.php");
        //实例化PHPMailer核心类
        $mail = new \PHPMailer();
        //使用smtp鉴权方式发送邮件
        $mail->isSMTP();
        //smtp需要鉴权 这个必须是true
        $mail->SMTPAuth=true;
        //链接qq域名邮箱的服务器地址
        $mail->Host = '192.168.2.99';
        //设置使用ssl加密方式登录鉴权
        //$mail->SMTPSecure = 'ssl';
        //设置ssl连接smtp服务器的远程服务器端口号，以前的默认是25，但是现在新的好像已经不可用了 可选465或587
        $mail->Port = 25;
        //设置发件人的主机域 可有可无 默认为localhost 内容任意，建议使用你的域名
        $mail->Hostname = 'ftracker.net';
        //设置发送的邮件的编码 可选GB2312 我喜欢utf-8 据说utf8在某些客户端收信下会乱码
        $mail->CharSet = 'UTF-8';
        //设置发件人姓名（昵称） 任意内容，显示在收件人邮件的发件人邮箱地址前的发件人姓名
        $mail->FromName = 'Ftracker';
        //smtp登录的账号 这里填入字符串格式的qq号即可
        $mail->Username ='test';
        //smtp登录的密码 使用生成的授权码（就刚才保存的最新的授权码）
        $mail->Password = '123456';
        //设置发件人邮箱地址 这里填入上述提到的“发件人邮箱”
        $mail->From = 'test@ftracker.net';
        //邮件正文是否为html编码 注意此处是一个方法 不再是属性 true或false
        $mail->isHTML(true);
        //设置收件人邮箱地址 该方法有两个参数 第一个参数为收件人邮箱地址 第二参数为给该地址设置的昵称 不同的邮箱系统会自动进行处理变动 这里第二个参数的意义不大
        $mail->addAddress($to,'尊敬的客户');
        //添加多个收件人 则多次调用方法即可
        // $mail->addAddress('xxx@163.com','尊敬的客户');
        //添加该邮件的主题
        $mail->Subject = $title;
        //添加邮件正文 上方将isHTML设置成了true，则可以是完整的html字符串
        $mail->Body = $content;
        $status = $mail->send();
        //判断与提示信息
        if($status) {
            return true;
        }else{
            return false;
        }
    }

      function logout(){
      	session(null);
      	$this->redirect('Index/index');
      }
    
      function a(){
            $cfg=array(
                   'fontSize' => 20,
                   'imageH'   => 50,
                   'imageW'   => 150,
                   'length'   => 4,
                   'fontttf'  => '4.ttf',
              );
             $vey= new \Think\Verify($cfg);
             $vey->entry();
      }
      function suggest(){

          $this->display();
          //获取反馈意见
          //存入数据库
          //返回处理结果，感谢用户
      }
      function suggestsave(){
          $data['userid']=session('id');
          $data['content']=I('suggestion');
          $a=M('suggestions')->where($data)->find();
          if(!$a){
          $re=M('suggestions')->add($data);
          if ($re){
              echo "谢谢您的建议,我们会继续加油的！";
          }}else{
              echo "请勿重复提交";
          }
      }
}

 ?>
