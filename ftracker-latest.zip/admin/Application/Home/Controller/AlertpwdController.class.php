<?php 

  namespace Home\Controller;
//use Think\Controller;
class AlertpwdController extends SessionController {

        function alertpwd(){
                  $id=session('id'); 
        	    if(IS_POST){
                      $data=I('post.');
                   
                                            
               $res=M('usertest')->where(array('username'=>$data['username'],'password'=>md5($data['password'])))->find();
                      if(!$res){
                      	$this->error('你输入的用户名或密码错误',U('alertpwd'));
                      }
                      	
                     if($data['pass1']!==$data['pass2']){
                     	$this->error('你输入新密码错误',U('alertpwd'));
                     } 

                       if($data['password']==$data['pass1']){
                          $this->error('原密码和新密码一样请重新填写',U('alertpwd'));
                     }  

                      $data['password']=md5($data['pass1']);
                 
                        $updateRes = D('usertest')->where("id=".$id)->save($data);   
                    if($updateRes){
                           $this->success('修改成功',U('Userindex/userindex'));
                    }else{
                           $this->error('修改失败',U('alertpwd'));
                     }       
        	    }else{
        	        $this->display();	
        	    }
        	 	
        }

 function deleteuser(){
           $data=I('get.');

          $a=D('usertest')->where("id=".$data['id'])->delete();
          if($a){
          	 session(null);
               $this->success('修改成功',U('Index/index'));
           }else{
               $this->error('修改失败',U('Userindex/userindex'));
             }
          }      
}

 ?>