<?php 
namespace Home\Controller;
use Think\Controller;
class SessionController extends Controller {

        function _initialize(){
        	if(!session('id')){
        		$this->error('你未登录,请登录后访问',U('Index/index'), 2);
        	}
        }
}

 ?>