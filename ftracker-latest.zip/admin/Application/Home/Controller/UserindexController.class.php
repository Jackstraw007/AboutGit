<?php

namespace Home\Controller;
use Think\Model;
class UserindexController extends SessionController {


    function _initialize(){
        if(!session('id')){
            $this->error('你未登录,请登录后访问',U('Index/index'), 2);}

        $id=session('id');
        $tagArr=M('collection')->field('tag')->where("userid=$id")->select();
        $tagArr=array_column($tagArr,'tag');
        $tagArr=implode(',', $tagArr);
        $tag=explode(',',$tagArr);
        foreach ($tag as $key => $value) {
            if (empty($value)) {
                unset($tag[$key]);
            }
        }
        $tag=array_unique($tag);
        //获取真标签
        $this->assign('tag',$tag);
    }


    function getTags(){


        //获取真标签
        $id=session('id');
        $tagArr=M('collection')->field('tag')->where("userid=$id")->select();
        $tagArr=array_column($tagArr,'tag');
        $tagArr=implode(',', $tagArr);
        $tag=explode(',',$tagArr);
        foreach ($tag as $key => $value) {
            if (empty($value)) {
                unset($tag[$key]);
            }
        }
        $tag=array_unique($tag);
        //获取真标签

    }

    function usermanage(){
        $userid=session('id');
        //$data=D('journal')->distinct('true')->field('description')->select();
        $data=D('journal')->field('description')->select();
        $data0=array();
        foreach ($data as $v) {
            $data0[]=$v['description'];
        }
        $data0=array_unique($data0);
        $arr=D('usertest')->where("id=$userid")->find();
        $customize=$arr['customize'];
        $arr=$arr['keywords'];
        $arr=explode(';',$arr);
        $this->assign('tagstring',$customize);
        $this->assign('arr', $arr);
        $this->assign('data', $data0);
        $this->display();
    }

    function userindex(){
        $id=session('id');
        $sql = "select articles from usertest where id=".$id;
        $mode = new \Think\Model();
        $rt = $mode->query($sql);
        if ($rt[0]['articles']!=null){
        $artid=$rt[0]['articles'];
        $artid=explode(',', $artid);
        foreach ($artid as $key => $value) {
            if (empty($value)) {
                unset($artid[$key]);
            }
        }
        array_unique($artid);
        $artid=implode(',', $artid);

        //分页开始
        $count=M('article')->where("id in ($artid)")->count();
        $page=new \Think\Page($count,10);
        $show=$page->show();
        $art=M('article')->where("id in ($artid)")->order('id desc')->limit($page->firstRow.','.$page->listRows)->select();
        foreach ($art as $k=>$v){
            $name=$v['journal'];
            $impactf=M('journal')->field('impactf')->where("name = '$name'")->select();
            $art[$k]['impactf']=$impactf[0]['impactf'];
        }
        $this->assign('art',$art);
        $this->assign('page',$show);
        $this->assign('count',$count);
        }else{
            $this->assign("art",null);
            $this->assign('count',0);
        }
        $this->display();
    }

    function journals(){
        //$name=I('name');
        //$journals=M('journal')->where("name like '{$name}%'")->select();
        $count=M('journal')->count();
        $page=new \Think\Page($count,25);
        $show=$page->show();
        $journals=M('journal')->order('name')->limit($page->firstRow.','.$page->listRows)->select();

        //$journals[$k][$totalnum]=$totalnum;
//        foreach ($journals as $k=>$v){
//
//            $totalnum=M('article')->where("time ='2017-9-4'and journal='".$v['name']."'")->count();
//            //$journals[$k][$totalnum]=$totalnum;
//            echo $totalnum;
//        }

        $this->assign('journals',$journals);
        $this->assign('page',$show);
        $this->assign('count',$count);
        $this->display();

    }
    function journalsearch(){
        //获取领域列表
        $data=D('journal')->field('description')->select();
        $data0=array();
        foreach ($data as $v) {
            $data0[]=$v['description'];
        }
        $data0=array_unique($data0);
        $this->assign('data', $data0);


        //获取搜索条件
   if (I('post.')){
        $message=I('post.');
        $name=$message['name'];
        $impactf=$message['impact_fact'];
        $field=$message['field'];
        /*
         array(3) {
  ["impact_fact"] => string(5) "1.000"
  ["field"] => string(9) "All Field"
  ["name"] => string(0) ""
}
          */
        if ($name!=null){

            $journals=M('journal')->where("name like '{$name}%'")->select();
        }else{
            if($field=='All Field'){
                $journals=M('journal')->where("impactf >=$impactf")->select();
            }else{
                $journals=M('journal')->where("impactf >=$impactf and description='$field'")->select();
            }
        }
        $this->assign('count',count($journals));
       $this->assign('journals',$journals);}
        //搜索查询
        //模板赋值
        $this->display();
    }

    function getKeywordsSql($keywords,$where){
        $arr=explode(' ', $keywords);
        $sqlstr='';
        foreach ($arr as $key => $value) {
            if ($value==' ') {
                continue;
            }
            $sqlstr.="and $where like '%$value%' ";
        }
        $sqlstr=trim($sqlstr,'and');
        return $sqlstr;
    }

    function artsearch(){

        if(IS_POST){
            $atts=I('post.');
            $checkbox1=$atts['checkbox1'];
            $checkbox2=$atts['checkbox2'];
            $checkbox3=$atts['checkbox3'];
            $checkbox4=$atts['checkbox4'];
            $data=D('journal')->field('description')->group('description')->select();
            if($checkbox4==null){
            $sqla=$this->getKeywordsSql($checkbox3,'b.abstract');
            $sqlt=$this->getKeywordsSql($checkbox3,'b.title');
            $sqlk=$this->getKeywordsSql($checkbox3,'b.keywords');

            if($checkbox2=='All Field'){
                $sql0=M('journal as a')
                    ->join("article as b on b.journal=a.name and a.impactf>=$checkbox1 ")
                    ->where("($sqla) or ($sqlt) or ($sqlk)")->order('b.getdate desc')->select();
            }else{
                $sql0=M('journal as a')
                    ->join("article as b on b.journal=a.name and a.impactf >=$checkbox1 and a.description='$checkbox2'")
                    ->where("($sqla) or ($sqlt) or ($sqlk)")->order('b.getdate desc')->select();

            }
           // $data=D('journal')->field('description')->group('description')->select();
//            $this->assign('atts', $atts);
//            $this->assign('data', $data);
//            $this->assign('sql0', $sql0);
//            $this->display();
                }else{
                $sql0=M('article')->where("journal like '{$checkbox4}%'" )->order('getdate desc')->select();
            }
            $this->assign('atts', $atts);
            $this->assign('data', $data);
            $this->assign('sql0', $sql0);
            $this->display();
        }else{
            $data=D('journal')->field('description')->group('description')->select();
            $this->assign('data', $data);
            $this->display();
        }
    }

    function subscribe(){
        $data=I('post.');
        $impact_fact=$data['impact_fact'];
        $field=$data['field'];
        $keywords=$data['keywords'];
        $id=session('id');
        $userkey=M('usertest')->field('keywords')->where("id='$id'")->find();

        $userkey=$userkey["keywords"];

        if(!$keywords){
            $str=$impact_fact.",".$field;
        }else{
            $str=$impact_fact.",".$field.",".$keywords;
        }
        if (!$userkey) {
            $userkey=$str;
        } else {
            $userkey=$userkey.";".$str;
        }


        $updateRes = M('usertest')->where("id='$id'")->setField('keywords',$userkey);
        if($updateRes){
            $this->success('订阅成功',U('userindex/usermanage'));
        }else{
            $this->error('订阅失败',U('userindex'));
        }
    }


    function subdelete(){
        $data=I('content');
        $id=session('id');
        $keywords=M('usertest')->field('keywords')->where("id='$id'")->find();
        $keywords=$keywords['keywords'];
        $keyarr=explode(";",$keywords);
        foreach ($keyarr as $key => $value) {
            if ($value===$data) {
                unset($keyarr[$key]);
            }
        }
        $keywords=implode(';', $keyarr);

        $updateRes = M('usertest')->where("id='$id'")->setField('keywords',$keywords);
        if($updateRes){
            $this->success('删除成功',U('userindex'));
        }else{
            $this->error('删除失败',U('userindex'));
        }
    }

    function labelset(){
        $userid=session('id');
        $data=I('post.');
        dump($data);
        $map=array("id"=>$userid);
        $updateRes=M('usertest')->where($map)->save($data);
        if($updateRes){
            $this->success('添加成功',U('Userindex/userindex'),1);
        }else{
            $this->error('添加失败',U('Userindex/userindex'),1);
        }
    }


    function artimportant1($id){//文章id

        $data['articleid']=$id;
        $uid = session('id');
        $data['userid']=$uid;
        //应该没有id为7
        $selectRes = M('collection')->where("articleid='$id' and userid='$uid'")->select();
        if($selectRes){
            echo 1;//要不就//
        }else{
            $res=M('collection')->where("articleid=$id and userid=$uid")->add($data);//

            echo $res?1:0;
        }
    }

    function col($id){
        $userid=session('id');
        $data=array();
        $data['userid']=$userid;
        $data['articleid']=$id;
        $coll=M('collection')->add($data);
        if($coll){
            echo 1;
        }else{
            echo 0;
        }
    }

    function test()
    {
        print(__PUBLIC__);
    }

}

?>