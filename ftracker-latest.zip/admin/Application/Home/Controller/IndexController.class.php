<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {

	function _empty(){
        	echo "非法操作";
        }

    public function index(){
    	
       $this->display();
    }

//    期刊列表


    function journals(){
        $name=I('name');
        $journals=M('journal')->where("name like '{$name}%'")->select();
        echo count($journals).'个结果：<hr>';
        foreach ($journals as $k=>$v){
            echo "<span style='color: red'>".($k+1)."</span>.".$v['name'].'&nbsp;&nbsp;&nbsp;';
        }
        echo <<<_END
        <hr>
        <button class="btn btn-primary" onclick="history.go(-1)">返回</button>
_END;

    }

     function a(){
      dump(md5(a123456));	
     }    

     function content($id){
        
        $arr=M('article')->where("id=$id")->find();
        $journal=$arr['journal'];
        //dump($arr);
        $ar=array('name'=>$journal);
        $impactf=M('journal')->field('impactf')->where($ar)->find();
        $arr['impactf']=$impactf['impactf'];
        if(!session('id')){
            $flag0=0;
        }else{
            $flag0=1;
             $userid=session('id');
             $col=M('collection')->where(array("userid"=>"$userid","articleid"=>"$id"))->find();
             $tags=$col['tag'];
             $tags=explode(',', $tags);

            
            foreach ($tags as $key => $value) {
             if (empty($value)) {
               unset($tags[$key]);
             }
            }

             $userTags=M('usertest')->field('customize')->where(array("id"=>"$userid"))->find();
             $userTags=$userTags['customize'];
             $userTags=explode('|', $userTags);

            
            foreach ($userTags as $key => $value) {
             if (empty($value)) {
               unset($userTags[$key]);
             }
            }

        }
        $this->assign('flag0',$flag0);
        $this->assign('tags',$tags);
        $this->assign('userTags',$userTags);
        $this->assign('col',$col);
        $this->assign('article',$arr);
        $this->display();
     }  
}
