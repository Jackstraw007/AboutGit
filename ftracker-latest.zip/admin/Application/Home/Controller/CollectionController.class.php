<?php 


  namespace Home\Controller;
//use Think\Controller;
  use Think\Model;
class CollectionController extends SessionController{
    function index(){
          $id=session('id'); 
          $articleid=M('collection')->field('articleid')->where("userid=$id")->select();

          //为查询准备IN条件
          $ids='';
          foreach ($articleid as $value) {
            $ids.=','.$value['articleid'];
          }
          $ids=trim($ids,',');

          if ($ids!='') {
            $arts=M('article')->where("id in($ids)")->order('id desc')->select();
          }else{$arts=null;}

        foreach ($arts as $key=>$v){
            $colid=$v['id'];
            $col=M('collection')->where("articleid = $colid and userid = $id")->find();
            $arts[$key]['note']=$col['note'];

        }


           $tagArr=M('collection')->field('tag')->where("userid=$id")->select();
          $tagArr=array_column($tagArr,'tag');
          $tagArr=implode(',', $tagArr);
          $tag=explode(',',$tagArr);
          foreach ($tag as $key => $value) {
             if (empty($value)) {
               unset($tag[$key]);
             }
           }          
           $tag=array_unique($tag);
           //获取真标签
           $this->assign('tag',$tag);
        
          $this->assign('art',$arts);
          $this->display();
          }


      function tree()
      {
        $userid=session('id');
        $folder=M('folder')->where("userid = '$userid'")->select();

        $this->assign('folder',$folder);
 
        $this->display();
      }

      function getTree()
      {
        $folderid=I('folderid');echo json_encode($folderid);
      }

      function saveNote(){
        $data=I('post.');
        $userid=session('id');
        $articleid=$data['articleid'];
        $save['note']=$data['note'];
        M('collection')->where("userid='$userid' and articleid='$articleid'")->save($save);
        echo '笔记保存成功';

      }

      function star(){
        $data=I('post.');
        $userid=session('id');
        $articleid=$data['articleid'];
        $save['level']=$data['level'];
        M('collection')->where("userid='$userid' and articleid='$articleid'")->save($save);
        
      
               }

    function saveTag(){
        $data=I('post.');
        $userid=session('id');
        $articleid=$data['id'];
        $save['tag']=$data['tag'];
        M('collection')->where("userid='$userid' and articleid='$articleid'")->save($save);
        echo '标签保存成功';            
    }

    function artlevel(){
    $userid=session('id');
     $tata=I('get.');
     $data=I('post.');
     $artecleid=$tata['id'];
     $updateRes = M('collection')->where("userId=$userid and articleId=$artecleid")->save($data);
     if($updateRes){
       $this->success('添加成功',U('Userindex/userlike'),1);
     }else{
      $this->error('添加失败',U('Userindex/userlike'),1);
     }
  }
 
    function collect(){
                if (!session('id'))  {    
                  echo '请登录';
                }
                $data['userid']=session('id');
                $data['articleid']=I('id');
                // $data['articleid']=I('id');
                // $data['level']=I('level');
                $data['level']=I('level');
               // $data['note']='hhhhh';
                // dump($data);
                // dump($tata);exit;
                $updateRes = M('collection')->add($data);
                //echo json_encode($updateRes);
                echo '收藏成功';
          
                   }
    function uncollect()
     {
        $map['articleid']=I('post.id');
        $map['userid']=session('id');
        $a=M('collection')->where($map)->delete();
        echo json_encode($a);
     
     }


     function tagart($tag){
         $userid=session('id');
$tagArr=M('collection')->field('tag')->where("userid=$userid")->select();
          $tagArr=array_column($tagArr,'tag');
          $tagArr=implode(',', $tagArr);
          $tags=explode(',',$tagArr);
          foreach ($tags as $key => $value) {
             if (empty($value)) {
               unset($tags[$key]);
             }
           }          
           $tags=array_unique($tags);
           //获取真标签
           $this->assign('tag',$tags);

        $arr=M('collection')->where("userid = $userid and tag like '%$tag%'")->select();
        $arr=array_column($arr, 'articleid');
        $artids=implode(',', $arr);
        $mode=new Model();
        $art=$mode->query("select a.*,j.impactf  from article a join journal j on a.journal=j.name where a.id in ($artids) order by a.getdate desc");
        $this->assign('tagone',$tag);
        $this->assign('art',$art);           
        $this->display();
     }
         
}

 ?>