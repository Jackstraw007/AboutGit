<?php 	
namespace Admin\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        $this->show('8');
    }
     public function index1(){
        $this->show('81');
    }
}