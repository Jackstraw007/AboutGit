<?php
return array(
	//'配置项'=>'配置值'
	'DB_TYPE'  => 'mysql',// 数据库类型 
    'DB_HOST'  => 'localhost',// 数据库服务器地址
    'DB_NAME'  => 'article',// 数据库名称
    'DB_USER'  => 'dell',// 数据库用户名
    'DB_PWD'  => 'bioruning',// 数据库密码
    //'DB_PREFIX'  => '',// 数据表前缀
    'DB_CHARSET' => 'utf8',// 网站编码
    'DB_PORT'  => '3306',// 数据库端口


    'TMPL_PARSE_STRING' => array(
        '__PUBLIC__' => __ROOT__ . '/Public',
        // '__JS__' => __ROOT__ . '/Public/Js',
        // '__CSS__' => __ROOT__ . '/Public/Css',
        // '__IMAGE__' => __ROOT__ . '/Public/Image',
        // '__DATA__' => __ROOT__ . '/Data/'
        '__TREE__'=>__ROOT__ . '/Public/Tree',
    ),
);