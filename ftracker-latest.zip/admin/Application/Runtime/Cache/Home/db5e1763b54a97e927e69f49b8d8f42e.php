<?php if (!defined('THINK_PATH')) exit();?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>用户管理</title>
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" type="text/css" href="/Public/Home/lib/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="/Public/Home/lib/bootstrap/css/bootstrap-responsive.css">
    <link rel="stylesheet" type="text/css" href="/Public/Home/stylesheets/theme.css">
    <link rel="stylesheet" href="/Public/Home/lib/font-awesome/css/font-awesome.css">

    <script src="/Public/Home/lib/jquery-1.8.1.min.js" type="text/javascript"></script>
    
    <!-- Demo page code -->
    <style type="text/css">
        .inbox {
        text-align:center;
        margin-left="5%";
        width:auto;
        height:40px;
        margin:50px auto;
        //border:1px solid black;
        //background:#50a3a2;
       // background: -webkit-linear-gradient(top left, #50a3a2 0%, #53e3a6 100%);
        //background: linear-gradient(to bottom right, #50a3a2 0%, #53e3a6 100%);
        border-radius:5px;
        float:left;
                                                                        
        }
        .sub-button{
        margin:auto;
        text-align: center;
        }
        input,button{height:30px;
            vertical-align:top}
        #line-chart {
            height:300px;
            width:800px;
            margin: 0px auto;
            margin-top: 1em;
        }
        .brand { font-family: georgia, serif; }
        .brand .first {
            color: #ccc;
            font-style: italic;
        }
        .brand .second {
            color: #fff;
            font-weight: bold;
        }
    </style>

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="../assets/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="../assets/ico/apple-touch-icon-57-precomposed.png">
  </head>

  <!--[if lt IE 7 ]> <body class="ie ie6"> <![endif]-->
  <!--[if IE 7 ]> <body class="ie ie7"> <![endif]-->
  <!--[if IE 8 ]> <body class="ie ie8"> <![endif]-->
  <!--[if IE 9 ]> <body class="ie ie9"> <![endif]-->
  <!--[if (gt IE 9)|!(IE)]><!--> 
  <body> 
  <!--<![endif]-->
    
    <div class="navbar">
        <div class="navbar-inner">
            <div class="container-fluid">
                <ul class="nav pull-right"> 
                    <li id="fat-menu" class="dropdown">
                        <a href="#" id="drop3" role="button" class="dropdown-toggle" data-toggle="dropdown">
                            <i class="icon-user"></i>
                          <?php echo $_SESSION['username']; ?>
                            <i class="icon-caret-down"></i>
                        </a>
                        <ul class="dropdown-menu">
                        <li><a tabindex="-1" href="<?php echo U('Register/logout');?>" onClick="return confirm('你确定退出吗？')">Logout</a></li>
                        </ul>

                    </li>
                    
                </ul>
                <a class="brand" href="/index.php?s=/Home/userindex/userindex"><span class="first">Frontier</span> <span class="second">Tracker</span></a>
            </div>
        </div>
    </div>
    

    <div class="container-fluid">
        
        <div class="row-fluid">
            <div class="span3">
                <div class="sidebar-nav">
                  <div class="nav-header" data-toggle="collapse" data-target="#dashboard-menu"><i class="icon-dashboard"></i>订阅</div>
                    <ul id="dashboard-menu" class="nav nav-list collapse in">
                        <li><a href="<?php echo U('Userindex/usermanage');?>">订阅管理</a></li>
                        <li><a href="<?php echo U('Userindex/journals');?>">期刊名录</a></li>
                        
                        
                    </ul>
                <div class="nav-header" data-toggle="collapse" data-target="#accounts-menu"><i class="icon-briefcase"></i>文章</div>
                <ul id="accounts-menu" class="nav nav-list collapse in">
                <li ><a href="<?php echo U('Userindex/userindex');?>">订阅文章列表</a></li>
                <li ><a href="<?php echo U('Collection/index');?>">我的收藏</a></li>
                <li ><a href="<?php echo U('Userindex/artsearch');?>">全局检索</a></li> 
                <li ><a href="<?php echo U('Userindex/artsearch2');?>">全局检索2</a></li> 
                </ul>

                <div class="nav-header" data-toggle="collapse" data-target="#settings-menu"><i class="icon-user"></i>用户</div>
                <ul id="settings-menu" class="nav nav-list collapse in">
                  <li ><a href="<?php echo U('Alertpwd/alertpwd');?>" >修改密码</a></li>
                  <li><a tabindex="-1" href="<?php echo U('Register/logout');?>" onClick="return confirm('你确定退出吗？')">退出登录</a></li>
                  <li><a tabindex="-1" href="<?php echo U('Register/suggest');?>">反馈建议</a></li>
                </ul>

                    <!--dragdown-->
                    <div class="btn-group">
                        <button type="button" class="btn btn-default dropdown-toggle"
                                data-toggle="dropdown">
                            <i class="icon icon-tags"></i>
                            我的标签 <i class="icon-list icon-white"></i></span>
                        </button>
                        <ul class="dropdown-menu" role="menu">
                            <?php if(empty($tag)): ?><li>赶紧加标记吧！</li><?php endif; ?>
                            <?php if(is_array($tag)): foreach($tag as $key=>$o): ?><li ><a href="/index.php?s=/Home/Collection/tagart/tag/<?php echo ($o); ?>" ><?php echo ($o); ?></a></li><?php endforeach; endif; ?>
                        </ul>
                    </div>
                    <!--dragdown-->
                </div>
        </div>


<div class="span9">
            <script type="text/javascript" src="/Public/Home/lib/jqplot/jquery.jqplot.min.js"></script>
<script type="text/javascript" charset="utf-8" src="javascripts/graphDemo.js"></script>
<div class="row-fluid">
    <div class="block">
        <p class="block-heading">订阅</p>
        <div id="chart-container" class="block-body collapse in">
            <form name='form' class="form" method='post' action="<?php echo U('Userindex/subscribe');?>">
               
                <div class="inbox">
                    <div class="title">
                        <span>Impact Factor</span>
                    </div>
                    
                    <div class="item">
                        <select name="impact_fact">
                            <option value="1.000">IF>=1.000</option>
                            <option value="2.000">IF>=2.000</option>
                            <option value="3.000">IF>=3.000</option>
                            <option value="4.000">IF>=4.000</option>
                            <option value="5.000">IF>=5.000</option>
                            <option value="6.000">IF>=6.000</option>
                            <option value="7.000">IF>=7.000</option>
                            <option value="8.000">IF>=8.000</option>
                            <option value="9.000">IF>=9.000</option>
                            <option value="10.000">IF>=10.000</option>
                            <option value="11.000">IF>=11.000</option>
                            <option value="12.000">IF>=12.000</option>
                        </select>
                    </div>

                </div>
                <div style="width:4%;float:left;height:80px">
                </div>     
                <div class="inbox">
                <div class="title">
                <span>Field</span>
                </div>
                <div class="item">
                
                <select name="field">
                    <option value="All Field">AField</option> 
                    
                     <?php if(is_array($data)): foreach($data as $key=>$vo): ?><option value = "<?php echo ($vo); ?>"> <?php echo ($vo); ?></option><?php endforeach; endif; ?> 

                </select>
                </div>

                </div>
                <div style="width:4%;float:left;height:80px">
                </div>
                <div class="inbox">
                <div class="title">
                <span>Keywords</span>
                </div>
                <input type="text" placeholder="输入你想订阅的关键字(空格间隔)" name="keywords" >
                  <button type="submit"   name='' value='submit'>订阅</button>
                </div>
                </form>
        </div>

        <p class="block-heading" >订阅管理</p>
        <div id="chart-container1" class="block-body collapse in">
            <div class="sub-content">
            <table class="table">
            <thead>
            <tr>
            <th>#</th>
            <th>Content</th>
            <th>Operate</th>
            
            <th style="width: 26px;"></th>
            </tr>
            </thead>
            <tbody>
     
         <?php if(is_array($arr)): foreach($arr as $k=>$vo): ?><tr>
            <td><?php echo ($k+1); ?></td>
            <td><?php echo ($vo); ?></td>
            <td><a href='/index.php?s=/Home/Userindex/subdelete/content/<?php echo ($vo); ?>'>删除</a></td>
            <!-- <td><a href='<?php echo U("subdelete?content=$vo");?>' onClick="return confirm('你确定删除吗？')">删除</a></td> -->
            </tr><?php endforeach; endif; ?>     
            </tbody>
            </table>
            </div>
        </div>
<p class="block-heading" >标签设定</p>
<div id="chart-container2" class="">

        <form name='form' class="form" method='post' action="<?php echo U('Userindex/labelset');?>">
        <div >
            <br>
        <input type="text"  value="<?php echo ($tagstring); ?>" name="customize" >&nbsp;默认标签设置(不同标签用“|”分隔)<br>
        <button  type="submit"   value='submit1'>保存</button>
        </div>
        </form>

</div>





        <!---->
        <!--<p class="block-heading" >可用期刊检索</p>-->
        <!--<div id="chart-container3" class="block-body collapse in">-->
            <!--<div class="sub-content">-->
                <!--<form action="<?php echo U('index/journals');?>" method="post">-->
                <!--<table class="table">-->
                    <!--<thead>-->
                    <!--<tr>-->
                        <!--<th > <input type="text" name="name" placeholder="请输入期刊名"> <input type="submit"></th>-->
                    <!--</tr>-->
                    <!--</thead>-->
                    <!--<tbody>-->

                    <!--</tbody>-->
                <!--</table>-->
                <!--</form>-->
            <!--</div>-->
        <!--</div>-->
<!---->
    </div>
</div>


    

    
    <footer>
        <hr>

        
        <p class="pull-right">Collect from </p>
        
        
        <p>&copy; 2017 <a href="#">biorun</a></p>
    </footer>
    

    

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="/Public/Home/lib/bootstrap/js/bootstrap.js"></script>
  

  </body>
</html>