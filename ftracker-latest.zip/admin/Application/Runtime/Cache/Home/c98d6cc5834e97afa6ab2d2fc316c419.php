<?php if (!defined('THINK_PATH')) exit();?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>用户管理</title>
<meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">

<link rel="stylesheet" type="text/css" href="/Public/Home/lib/bootstrap/css/bootstrap.css">

<link rel="stylesheet" type="text/css" href="/Public/Home/stylesheets/theme.css">

<link rel="stylesheet" href="/Public/Home/lib/font-awesome/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="/Public/Home/lib/bootstrap/css/bootstrap-responsive.css">

<!-- 10.17 -->
<link href="http://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet">
<script src="http://libs.baidu.com/jquery/1.10.2/jquery.min.js"></script>




<script src="/Public/Home/lib/jquery-1.8.1.min.js" type="text/javascript"></script>


<!-- Demo page code -->

<style type="text/css">
        .inbox {
        margin-left="5%";
        width:28%;
        height:80px;
        margin:50px auto;
        border:1px solid black;
        background:#50a3a2;
        background: -webkit-linear-gradient(top left, #50a3a2 0%, #53e3a6 100%);
        background: linear-gradient(to bottom right, #50a3a2 0%, #53e3a6 100%);
        border-radius:5px;
        float:left;

        }
        input,button{
        height:30px;
        vertical-align:top
                            }
        #line-chart {
        height:300px;
        width:800px;
        margin: 0px auto;
        margin-top: 1em;
        }
        .brand { font-family: georgia, serif; }
        .brand .first {
        color: #ccc;
        font-style: italic;
        }
        .brand .second {
        color: #fff;
        font-weight: bold;
        }
</style>


<!-- 标签特效 --> 
    <script type="text/javascript" src="/Public/tag/examples/jquery_ui/js/jquery-1.9.0.js"></script>
    <script type="text/javascript" src="/Public/tag/examples/jquery_ui/js/jquery-ui-1.10.0.custom.min.js"></script>
    <script type="text/javascript" src="/Public/tag/examples/js/google-code-prettify/prettify.js"></script>
    <script type="text/javascript" src="/Public/tag/js/jquery.taghandler.min.js" ></script>
    <script type="text/javascript" src="/Public/tag/examples/js/jquery.mockjax.js"></script>
    <script type="text/javascript" src="/Public/tag/examples/js/examples_ajaxmock.js"></script>
    <link type="text/css" href="/Public/tag/css/jquery.taghandler.min.css" rel="stylesheet">
    <link type="text/css" href="/Public/tag/examples/jquery_ui/css/smoothness/jquery-ui.css" rel="stylesheet">
    <link type="text/css" href="/Public/tag/examples/js/google-code-prettify/prettify.css" rel="stylesheet">                           
<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<!-- Le fav and touch icons -->
<link rel="shortcut icon" href="../assets/ico/favicon.ico">
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/ico/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/ico/apple-touch-icon-114-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/ico/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="../assets/ico/apple-touch-icon-57-precomposed.png">

<!-- 10.17 -->
<link href="/Public/Home/css/star-rating.css" media="all" rel="stylesheet" type="text/css"/>
<script src="/Public/Home/js/star-rating.js" type="text/javascript"></script>
</head>
                                    
<!--[if lt IE 7 ]> <body class="ie ie6"> <![endif]-->
<!--[if IE 7 ]> <body class="ie ie7"> <![endif]-->
<!--[if IE 8 ]> <body class="ie ie8"> <![endif]-->
<!--[if IE 9 ]> <body class="ie ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<body>
<!--<![endif]-->
<div class="navbar">
    <div class="navbar-inner">
        <div class="container-fluid">
            <ul class="nav pull-right">
                <li id="fat-menu" class="dropdown">
                    <a href="#" id="drop3" role="button" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="icon-user"></i>
                        <?php echo $_SESSION['username']; ?>
                        <i class="icon-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu">
                        <li><a tabindex="-1" href="<?php echo U('Register/logout');?>" onClick="return confirm('你确定退出吗？')">Logout</a></li>
                    </ul>

                </li>

            </ul>
            <a class="brand" href="/index.php?s=/Home/userindex/userindex"><span class="first">Frontier</span> <span class="second">Tracker</span></a>
        </div>
    </div>
</div>


<div class="container-fluid">

    <div class="row-fluid">
        <div class="spa12">

<script type="text/javascript" src="/Public/Home/lib/jqplot/jquery.jqplot.min.js"></script>
        <script type="text/javascript" charset="utf-8" src="javascripts/graphDemo.js"></script>
            <h1 class="page-title">文章详情</h1>
            id:<?php echo ($article["id"]); ?>

            
 
       

<div class="well">

   <p> 
       <sapn style="font-weight:bold;font-size:16px">Title:</sapn><?php echo ($article["title"]); ?><br>
       <sapn style="font-weight:bold;font-size:16px">标题:</sapn><?php echo ($article["title_zh"]); ?>
   </p>
    <div>
         <sapn style="font-weight:bold;font-size:16px;float:left">Abstract:</sapn>
            <p class="cont"><?php echo ($article["abstract"]); ?> </p>
          <sapn style="font-weight:bold;font-size:16px;float:left">摘要:</sapn>
            <p class="cont"><?php echo ($article["abstract_zh"]); ?> </p>
    </div>
    <?php if($article['keywords']== ''){ ?>
    <?php }else{?>
    <p>
       <sapn style="font-weight:bold;font-size:16px"> Keywords:</sapn>
           <?php echo $article['keywords'];?>
           <br>
        <sapn style="font-weight:bold;font-size:16px"> 关键词:</sapn>
           <?php echo $article['keywords_zh'];?>
     </p>
     <?php }?>
    <p>
       <sapn style="font-weight:bold;font-size:16px">Author:
             </sapn> <?php echo ($article["author"]); ?> 
    </p>
    <p> 
       <sapn style="font-weight:bold;font-size:16px">Journal:
    </sapn><?php echo ($article["journal"]); ?> 
        &nbsp(impactf(影响因子):<?php echo ($article["impactf"]); ?>)
        &nbsp&nbsp<?php echo ($article["getdate"]); ?>
        &nbsp&nbsp
        <a href="<?php echo ($article["link"]); ?>" target="_black">全文链接</a>
    </p>
<hr> 
<?php if($flag0==0){?>

请<a class="btn btn-primary btn-xs" href="http://admin.cw/index.php?s=/Home/Register/logina/articleid/<?php echo $article['id'] ?>" >登录</a>后进行更多操作！
<?php }else{ ?>                             
<?php if(!$col){ ?>
        <!-- star -->
   <!--  <input id="input-2b" type="number" class="rating" min="0" max="5" step="1" data-size="xl"
    data-symbol="&#xe005;" data-default-caption="{rating} hearts" data-star-captions="{}">
    <br> -->
    <input id="input-21a"  name='level' value="1" type="number" class="rating" min=0 max=5 step=1 data-size="xs" >
    <br>
<p class="help-block">设置文章评分，默认值为1（范围1-5）</p>
    <div class="clearfix"></div>
    <div class="form-group form-inline">
    <button onclick="collect(<?php echo ($article["id"]); ?>)" class="btn btn-primary">收藏</button>
    <!-- <button type="reset" class="btn btn-default">Reset</button> -->
    </div>


<?php }else{ ?>


<h5>我的笔记：<a class="btn btn-primary btn-sm" id="a" onclick="edit()">编辑笔记</a></h5>
<div id="note" style="background-color: rgba(125,125,12,0.2);border-radius: 5px">
    <?php if($col['note']==''){ echo "***暂无笔记***"; }else{echo $col['note'];}?> 
</div>
<br>
<h5>文章等级：</h5>
<input id="input-21a"  name='level' value="<?php echo ($col["level"]); ?>" type="number" class="rating" min=0 max=5 step=1 data-size="xs" >
<a class='btn btn-primary btn-sm' id='b' onclick='star(<?php echo $article['id'];?>)'>提交评分</a>

<br><br>
<h5>标签：</h5>
<ul id="examples_autocomplete" class="panel-info"></ul>
    <button class="btn btn-xs btn-success"
            onclick="saveTag(<?php echo ($article["id"]); ?>)">
        <span class="ui-button-text">保存标签</span>
    </button>
<button onclick="uncollect(<?php echo ($article["id"]); ?>)" class="btn btn-danger btn-xs pull-right">取消收藏</button>
<?php } ?>

<button onclick="history.go(-1)">返回上一页</button>
<!--<button onclick="a()">返回上一页</button>-->

</div>
<?php }?>
<script type="text/javascript">

    function a() {
        history.go(-1)
    }
  function edit(){
       var notediv=$('#note')
       note=notediv.text();
       if (note=='') {
        alert(1)
       }
        notediv.html("<input id='note1' value="+note+" name='note'>");
        $('#a').replaceWith("<a class='btn btn-primary btn-sm' id='b' onclick='save(<?php echo $article['id'];?>)'>保存</a></h5>");


  }
  function save(id){
     var v=$('#note1').val();
     $.ajax({
         url: '/index.php?s=/Home/Collection/saveNote',
         type: 'post',
         dataType: 'html',
         data: {note:v,articleid:id},
     })
     .done(function(date) {
         alert(date);
         location.reload(); 
     })
     .fail(function() {
         alert('保存失败');
     });
     
  }
   function star(id){
        var level=$("#input-21a").val();
        $.ajax({
                type: 'post',
                url: '/index.php?s=/Home/Collection/star',
                data: {articleid :id,level:level},
                dataType: 'text',
                success: function(){
                    alert('提交成功');
                },
                error: function(data){
                    alert('设置失败');
                }
  })
    }

function saveTag(id){

    var tag=$("#examples_autocomplete").tagHandler("getTags").join(",");

    $.ajax({
        url: '/index.php?s=/Home/Collection/saveTag',
        type: 'post',
        dataType: 'text',
        data: {id :id,tag:tag},
    })
    .done(function(a) {
        alert(a);
    })
    .fail(function() {
        console.log("error");
    })
    .always(function() {
        console.log("complete");
    });
    
}

  function collect(id){
        var isconfirm = confirm("你确定收藏吗？"); 
        var level=$("#input-21a").val();
        if(!id){alert('错误');return false;}
        $.ajax({
                type: 'post',
                url: '/index.php?s=/Home/Collection/collect',
                data: {id :id,level:level},
                dataType: 'text',
                success: function(code){ 
                    if(code){
                      alert(code); 
                         location.reload();  
                    }else{
                        alert('收藏失败');
                    }               
                },
                error: function(data){
                    alert('设置失败');
                }
        });
    }

    function uncollect(id){
        var isconfirm = confirm("你确定取消吗？"); 
        if(!isconfirm){ return;}
        $.ajax({
                type: 'post',
                url: '/index.php?s=/Home/Collection/uncollect',
                data: {id: id },
                dataType: 'json',
                success: function(code){ 
                    if(code){
                      alert('取消成功'); 
                         location.reload();  
                    }else{
                        alert('取消失败');
                    }               
                },
                error: function(data){
                    alert('操作失败');
                }
        });
    }  
</script>


    
 
    
    <footer>
        <hr>
        <p>&copy; 2017 <a href="#">biorun</a></p>
    </footer>
    

    

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="/Public/Home/lib/bootstrap/js/bootstrap.js"></script>
    
    
    
    

   
    
 <script>
    jQuery(document).ready(function () {
        $(".rating-kv").rating();

         $("#examples_autocomplete").tagHandler({
               // assignedTags: [ 'Web', 'Perl', 'PHP' ],
                assignedTags: [ 
                    <?php  foreach($tags as $v){ echo "'".$v."',"; } ?>
                 ],
                availableTags: [
                      <?php  foreach($userTags as $v){ echo "'".$v."',"; } ?>
                 ],
                autocomplete: true
            });

    });
</script>   
    
    
  
  </body>

</html>