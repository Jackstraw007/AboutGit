<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML>
<html>

	<head>
		<meta charset="utf-8" />
		<title>我的收藏夹</title>
        <link rel="stylesheet" type="text/css" href="http://www.jq22.com/jquery/font-awesome.4.6.0.css">
		<style type="text/css">
			* {
				padding: 0;
				margin: 0;
				font-family: "microsoft yahei";
			}
			
			ul li {
				list-style-type: none;
			}
			
			.box {
				width: 200px;
				/*border: 1px solid red;*/
			}
			
			ul {
				margin-left: 20px;
				/*border: 1px solid blue;*/
			}
			
			.menuUl li {
				margin: 10px 0;
			}
			
			.menuUl li span:hover {
				text-decoration: underline;
				cursor: pointer;
			}
			
			.menuUl li i { margin-right: 10px; top: 0px; cursor: pointer; color: #161616; 			}
		</style>
	</head>

	<body>
		<div class="innerUl">
		</div>
		<div class="content">
			
		</div>
	</body>
	<script src="http://www.jq22.com/jquery/jquery-1.10.2.js"></script>
	<script type="text/javascript" src="/Public/Tree/js/proTree.js" ></script>
	<script type="text/javascript">
		//后台传入的 标题列表
		var arr = [
			// {
			// 	id: 1,
			// 	name: "<?php echo ($folder["0"]["folder"]); ?>",
			// 	pid: 0
			// }, 
			<?php if(is_array($folder)): foreach($folder as $key=>$v): ?>{
				id: <?php echo ($v["id"]); ?>,
				name: "<?php echo ($v["folder"]); ?>",
				pid: <?php echo ($v["pid"]); ?>
			},<?php endforeach; endif; ?>

		];
        //标题的图标是集成bootstrap 的图标  更改 请参考bootstrap的字体图标替换自己想要的图标
		$(".innerUl").ProTree({
			arr: arr,
			simIcon: "fa fa-file-o",//单个标题字体图标 不传默认glyphicon-file
			mouIconOpen: "fa fa-folder-open-o",//含多个标题的打开字体图标  不传默认glyphicon-folder-open
			mouIconClose:"fa fa-folder-o",//含多个标题的关闭的字体图标  不传默认glyphicon-folder-close
			callback: function(id,name) {
				$.ajax({
                type: 'post',
                url: '/index.php?s=/Home/Collection/getTree',
                data: {folderid: id },
                dataType: 'json',
                success: function(code){
                 	alert(code);
                },    
                error: function(data){
                    alert('设置失败');
                }
            });
				
				//$(".content").html(id);
				//alert("你选择的id是" + id + "，名字是" + name);
			}

		})
	</script>

</html>