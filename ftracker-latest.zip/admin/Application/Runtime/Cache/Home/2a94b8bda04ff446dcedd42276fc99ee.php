<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>

<!-- Head -->
<head>

<title>Home</title>

<!-- Meta-Tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="keywords" content="">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //Meta-Tags -->


	<link rel="stylesheet" href="https://cdn.bootcss.com/font-awesome/4.7.0/css/font-awesome.css">

<!-- Style --> <link rel="stylesheet" href="/Public/Home/css/style1.css" type="text/css" media="all">

<!-- Fonts -->
<link href="http://fonts.googleapis.com/css?family=Quicksand:300,400,500,700" rel="stylesheet">
<!-- //Fonts -->

</head>
<!-- //Head -->

<!-- Body -->
<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1263867126'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s13.cnzz.com/z_stat.php%3Fid%3D1263867126%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</script>
<script>document.getElementById('cnzz_stat_icon_1263867126').style.display="none"</script>
<body>

	<h1>the frontier tracker</h1>
	<div class="w3layout-agileits">
	<h3>intorduction</h3>
	<h3>the frontier tracker is a faster tracker</h3>
	<p></p>
	<p>if you want to get the latest academic articles you are interested in</p>
    <p>maybe our website can help you</p>
    <p>we provide three choice for articles you are intersted in</p>
    <p>you can subscribe to the articles you are interssted in through impact factor，field and keyword</p>
    <p>if you are intersted in our function just go to register </p>
	<a href="<?php echo U('Register/register');?>">go to register <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
    <a href="<?php echo U('Register/login');?>">go to login <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
	</div>

	<div class="w3footeragile">
		<p>Copyright &copy; 2017.biorun All rights reserved<a target="_blank" href="http://www.biorun.com">伯远生物</a></p>
	</div>

</body>
<!-- //Body -->

</html>