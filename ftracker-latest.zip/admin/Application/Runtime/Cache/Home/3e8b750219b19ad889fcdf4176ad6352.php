<?php if (!defined('THINK_PATH')) exit();?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>用户反馈</title>
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" type="text/css" href="/Public/Home/lib/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="/Public/Home/lib/bootstrap/css/bootstrap-responsive.css">
    <link rel="stylesheet" type="text/css" href="/Public/Home/stylesheets/theme.css">
    <link rel="stylesheet" href="/Public/Home/lib/font-awesome/css/font-awesome.css">
      <link rel="stylesheet" type="text/css" href="/Public/page.css">
    <script src="/Public/Home/lib/jquery-1.8.1.min.js" type="text/javascript"></script>
    
    <!-- Demo page code -->
    <style type="text/css">
        .inbox {
        text-align:center;
        margin-left="5%";
        width:auto;
        height:40px;
        margin:50px auto;
        //border:1px solid black;
        //background:#50a3a2;
       // background: -webkit-linear-gradient(top left, #50a3a2 0%, #53e3a6 100%);
        //background: linear-gradient(to bottom right, #50a3a2 0%, #53e3a6 100%);
        border-radius:5px;
        float:left;
                                                                        
        }
        .sub-button{
        margin:auto;
        text-align: center;
        }
        input,button{height:30px;
            vertical-align:top}
        #line-chart {
            height:300px;
            width:800px;
            margin: 0px auto;
            margin-top: 1em;
        }
        .brand { font-family: georgia, serif; }
        .brand .first {
            color: #ccc;
            font-style: italic;
        }
        .brand .second {
            color: #fff;
            font-weight: bold;
        }
    </style>

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="../assets/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../assets/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../assets/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../assets/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="../assets/ico/apple-touch-icon-57-precomposed.png">
  </head>

  <!--[if lt IE 7 ]> <body class="ie ie6"> <![endif]-->
  <!--[if IE 7 ]> <body class="ie ie7"> <![endif]-->
  <!--[if IE 8 ]> <body class="ie ie8"> <![endif]-->
  <!--[if IE 9 ]> <body class="ie ie9"> <![endif]-->
  <!--[if (gt IE 9)|!(IE)]><!--> 
  <body> 
  <!--<![endif]-->



  <div class="navbar">
      <div class="navbar-inner">
          <div class="container-fluid">
              <ul class="nav pull-right">
                  <li id="fat-menu" class="dropdown">
                      <a href="#" id="drop3" role="button" class="dropdown-toggle" data-toggle="dropdown">
                          <i class="icon-user"></i>
                          <?php echo $_SESSION['username']; ?>
                          <i class="icon-caret-down"></i>
                      </a>
                      <ul class="dropdown-menu">
                          <li><a tabindex="-1" href="<?php echo U('Register/logout');?>" onClick="return confirm('你确定退出吗？')">Logout</a></li>
                      </ul>

                  </li>

              </ul>
              <a class="brand" href="/index.php?s=/Home/userindex/userindex"><span class="first">Frontier</span> <span class="second">Tracker</span></a>
          </div>
      </div>
  </div>



            <script type="text/javascript" src="/Public/Home/lib/jqplot/jquery.jqplot.min.js"></script>
<script type="text/javascript" charset="utf-8" src="javascripts/graphDemo.js"></script>
    <h2 class="page-title " style="line-height: 20px" align="center">请输入您的宝贵建议</h2>
    <div class="well">


        <div align="center">
            <textarea class="form-control" rows="15" style="width: 80%" ></textarea><br>
            <button onclick="suggest()" class="btn">提交</button>
        </div>

    </div>

</div>
</div>





  <footer>
        <hr>

        
        <p class="pull-right">Collect from </p>
        
        
        <p>&copy; 2017 <a href="#">biorun</a></p>
    </footer>
    

    

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="/Public/Home/lib/bootstrap/js/bootstrap.js"></script>
  <script>

          function suggest(){
              var suggestion=$('textarea').val()
              $.ajax({
                  url: "<?php echo U('Register/suggestsave');?>",
                  type: 'post',
                  dataType:'html',
                  data: {suggestion: suggestion},
                  success: function(data){
                      alert(data);
                  },
                  error: function(data){
                      alert('设置失败');
                  }
              })

          }


  </script>

  </body>
</html>